#ifndef WINDOWSGL_GEN_ALL_HPP
#define WINDOWSGL_GEN_ALL_HPP

#include "_int_wgl_type.hpp"
#include "_int_wgl_exts.hpp"

#endif /*WINDOWSGL_GEN_ALL_HPP*/
